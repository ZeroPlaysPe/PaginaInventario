import bd.Conexion;
import java.sql.Connection;
import javax.swing.JOptionPane;

public class PruebaConexion {
    public static void main(String[] args) {
        try (Connection con = Conexion.getConexion()) {
            JOptionPane.showMessageDialog(null, "Conexión OK a la base de datos");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de conexión: " + e.getMessage());
        }
    }
}
