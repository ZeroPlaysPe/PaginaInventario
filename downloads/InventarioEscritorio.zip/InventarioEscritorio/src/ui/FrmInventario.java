package ui;

import bd.Conexion;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FrmInventario extends JFrame {

    private JTable tblProductos;
    private DefaultTableModel modelo;
    private JTextField txtNombre;
    private JTextField txtCategoria;
    private JTextField txtPrecioCompra;
    private JTextField txtPrecioVenta;
    private JTextField txtStock;
    private JTextField txtFechaVencimiento;
    private JButton btnAgregar;
    private JButton btnEditar;
    private JButton btnEliminar;
    private JButton btnLimpiar;

    public FrmInventario() {
        initComponents();
        cargarTabla();
    }

    private void initComponents() {
        setTitle("Inventario - App de Escritorio");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Tabla
        modelo = new DefaultTableModel(
                new Object[]{"ID", "Nombre", "Categoría", "Precio compra", "Precio venta", "Stock", "Fecha venc."},
                0
        );
        tblProductos = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tblProductos);
        add(scroll, BorderLayout.CENTER);

        // Panel de campos
        JPanel panelCampos = new JPanel(new GridLayout(3, 4, 5, 5));
        txtNombre = new JTextField();
        txtCategoria = new JTextField();
        txtPrecioCompra = new JTextField();
        txtPrecioVenta = new JTextField();
        txtStock = new JTextField();
        txtFechaVencimiento = new JTextField(); // formato AAAA-MM-DD

        panelCampos.add(new JLabel("Nombre:"));
        panelCampos.add(txtNombre);
        panelCampos.add(new JLabel("Categoría:"));
        panelCampos.add(txtCategoria);

        panelCampos.add(new JLabel("Precio compra:"));
        panelCampos.add(txtPrecioCompra);
        panelCampos.add(new JLabel("Precio venta:"));
        panelCampos.add(txtPrecioVenta);

        panelCampos.add(new JLabel("Stock:"));
        panelCampos.add(txtStock);
        panelCampos.add(new JLabel("Fecha venc. (AAAA-MM-DD):"));
        panelCampos.add(txtFechaVencimiento);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        btnAgregar = new JButton("Agregar");
        btnEditar = new JButton("Editar");
        btnEliminar = new JButton("Eliminar");
        btnLimpiar = new JButton("Limpiar");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        // Panel inferior que contiene campos + botones
        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.add(panelCampos, BorderLayout.CENTER);
        panelInferior.add(panelBotones, BorderLayout.SOUTH);

        add(panelInferior, BorderLayout.SOUTH);

        // Listeners
        btnAgregar.addActionListener(e -> agregarProducto());
        btnEditar.addActionListener(e -> editarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());
        btnLimpiar.addActionListener(e -> limpiarCampos());

        tblProductos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                llenarCamposDesdeTabla();
            }
        });

        setSize(900, 500);
        setLocationRelativeTo(null); // centrar
    }

    private void cargarTabla() {
        // Limpia la tabla
        modelo.setRowCount(0);

        try (Connection con = Conexion.getConexion()) {
            String sql = "SELECT * FROM productos ORDER BY nombre";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[7];
                fila[0] = rs.getInt("id");
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("categoria");
                fila[3] = rs.getDouble("precio_compra");
                fila[4] = rs.getDouble("precio_venta");
                fila[5] = rs.getInt("stock");
                fila[6] = rs.getDate("fecha_vencimiento");
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + ex.getMessage());
        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtCategoria.setText("");
        txtPrecioCompra.setText("");
        txtPrecioVenta.setText("");
        txtStock.setText("");
        txtFechaVencimiento.setText("");
        tblProductos.clearSelection();
    }

    private void llenarCamposDesdeTabla() {
        int fila = tblProductos.getSelectedRow();
        if (fila == -1) return;

        txtNombre.setText(modelo.getValueAt(fila, 1).toString());
        txtCategoria.setText(modelo.getValueAt(fila, 2) == null ? "" : modelo.getValueAt(fila, 2).toString());
        txtPrecioCompra.setText(modelo.getValueAt(fila, 3).toString());
        txtPrecioVenta.setText(modelo.getValueAt(fila, 4).toString());
        txtStock.setText(modelo.getValueAt(fila, 5).toString());
        txtFechaVencimiento.setText(
                modelo.getValueAt(fila, 6) == null ? "" : modelo.getValueAt(fila, 6).toString()
        );
    }

    private void agregarProducto() {
        String nombre = txtNombre.getText().trim();
        String categoria = txtCategoria.getText().trim();
        String pcStr = txtPrecioCompra.getText().trim();
        String pvStr = txtPrecioVenta.getText().trim();
        String stockStr = txtStock.getText().trim();
        String fechaStr = txtFechaVencimiento.getText().trim();

        if (nombre.isEmpty() || pcStr.isEmpty() || pvStr.isEmpty() || stockStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nombre, precios y stock son obligatorios.");
            return;
        }

        try (Connection con = Conexion.getConexion()) {
            String sql = "INSERT INTO productos (nombre, categoria, precio_compra, precio_venta, stock, fecha_vencimiento) "
                    + "VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, categoria.isEmpty() ? null : categoria);
            ps.setDouble(3, Double.parseDouble(pcStr));
            ps.setDouble(4, Double.parseDouble(pvStr));
            ps.setInt(5, Integer.parseInt(stockStr));
            if (fechaStr.isEmpty()) {
                ps.setDate(6, null);
            } else {
                ps.setDate(6, Date.valueOf(fechaStr)); // formato AAAA-MM-DD
            }

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Producto agregado.");
            cargarTabla();
            limpiarCampos();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al agregar: " + ex.getMessage());
        }
    }

    private void editarProducto() {
        int fila = tblProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto de la tabla.");
            return;
        }

        int id = (int) modelo.getValueAt(fila, 0);

        String nombre = txtNombre.getText().trim();
        String categoria = txtCategoria.getText().trim();
        String pcStr = txtPrecioCompra.getText().trim();
        String pvStr = txtPrecioVenta.getText().trim();
        String stockStr = txtStock.getText().trim();
        String fechaStr = txtFechaVencimiento.getText().trim();

        try (Connection con = Conexion.getConexion()) {
            String sql = "UPDATE productos SET nombre=?, categoria=?, precio_compra=?, precio_venta=?, stock=?, fecha_vencimiento=? "
                    + "WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, categoria.isEmpty() ? null : categoria);
            ps.setDouble(3, Double.parseDouble(pcStr));
            ps.setDouble(4, Double.parseDouble(pvStr));
            ps.setInt(5, Integer.parseInt(stockStr));
            if (fechaStr.isEmpty()) {
                ps.setDate(6, null);
            } else {
                ps.setDate(6, Date.valueOf(fechaStr));
            }
            ps.setInt(7, id);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Producto actualizado.");
            cargarTabla();
            limpiarCampos();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al editar: " + ex.getMessage());
        }
    }

    private void eliminarProducto() {
        int fila = tblProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto.");
            return;
        }

        int id = (int) modelo.getValueAt(fila, 0);

        int resp = JOptionPane.showConfirmDialog(this,
                "¿Eliminar el producto seleccionado?",
                "Confirmar", JOptionPane.YES_NO_OPTION);

        if (resp != JOptionPane.YES_OPTION) return;

        try (Connection con = Conexion.getConexion()) {
            String sql = "DELETE FROM productos WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Producto eliminado.");
            cargarTabla();
            limpiarCampos();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + ex.getMessage());
        }
    }
}
