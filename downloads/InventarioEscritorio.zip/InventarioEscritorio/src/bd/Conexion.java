package bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    // DATOS DE TU MYSQL (XAMPP)
    private static final String URL  = "jdbc:mysql://localhost:3306/inventario_escritorio?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root"; // en XAMPP normalmente es root
    private static final String PASS = "";     // en XAMPP suele estar vacío

    public static Connection getConexion() throws SQLException {
        try {
            // Cargar el driver de MySQL (el .jar que agregaste)
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("No se encontró el driver de MySQL", ex);
        }

        // Conectar y devolver la conexión
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
